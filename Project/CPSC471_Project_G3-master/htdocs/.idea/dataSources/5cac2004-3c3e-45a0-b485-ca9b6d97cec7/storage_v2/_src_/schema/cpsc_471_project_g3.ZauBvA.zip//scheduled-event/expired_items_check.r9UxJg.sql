create definer = root@localhost event expired_items_check on schedule
    every '1' DAY
        starts '2019-12-02 00:00:00'
    on completion preserve
    enable
    do
    delete
       from item
       where days_to_expire = 0;

