create definer = root@localhost trigger order_date_of_order_insert
    before INSERT
    on `order`
    for each row
begin
    set new.date_of_order = curdate();
end;

