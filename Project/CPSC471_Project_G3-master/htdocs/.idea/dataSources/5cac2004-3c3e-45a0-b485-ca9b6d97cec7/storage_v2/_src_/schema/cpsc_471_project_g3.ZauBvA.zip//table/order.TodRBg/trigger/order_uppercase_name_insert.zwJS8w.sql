create definer = root@localhost trigger order_uppercase_name_insert
    before INSERT
    on `order`
    for each row
begin
    if (new.first_name_of_receiver regexp binary '^[a-z]+$') = 0 then
        signal sqlstate '12345'
            set message_text = 'invalid first name!';
    elseif (new.last_name_of_receiver regexp binary '^[a-z]+$') = 0 then
        signal sqlstate '12345'
            set message_text = 'invalid last name!';
    end if;
end;

