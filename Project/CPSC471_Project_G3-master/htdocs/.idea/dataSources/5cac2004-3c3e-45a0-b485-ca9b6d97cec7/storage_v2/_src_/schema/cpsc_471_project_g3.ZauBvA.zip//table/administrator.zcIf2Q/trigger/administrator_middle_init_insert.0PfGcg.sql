create definer = root@localhost trigger administrator_middle_init_insert
    before INSERT
    on administrator
    for each row
begin
    if (new.middle_initial is not null) and (new.middle_initial regexp binary '^[a-z]$') = 0 then
        signal sqlstate '12345'
            set message_text = 'invalid middle initial!';
    end if;
end;

