create definer = root@localhost trigger campus_email_address_format_check_before_update
    before UPDATE
    on ucalgary_member
    for each row
begin
    if (new.campus_email_address regexp
        '^[a-za-z0-9][a-za-z0-9._-]*[a-za-z0-9._-]@[a-za-z0-9][a-za-z0-9._-]*[a-za-z0-9]\\.[a-za-z]{2,63}$') =
       0 then /* 1-123-123-123 */
        signal sqlstate '12345'
            set message_text = 'invalid email format!';
    end if;
end;

