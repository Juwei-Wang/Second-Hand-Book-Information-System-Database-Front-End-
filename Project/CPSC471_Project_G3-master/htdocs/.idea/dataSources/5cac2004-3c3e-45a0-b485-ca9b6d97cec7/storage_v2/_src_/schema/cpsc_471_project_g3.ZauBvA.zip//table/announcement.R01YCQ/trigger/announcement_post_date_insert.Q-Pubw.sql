create definer = root@localhost trigger announcement_post_date_insert
    before INSERT
    on announcement
    for each row
begin
    set new.post_date = curdate();
end;

