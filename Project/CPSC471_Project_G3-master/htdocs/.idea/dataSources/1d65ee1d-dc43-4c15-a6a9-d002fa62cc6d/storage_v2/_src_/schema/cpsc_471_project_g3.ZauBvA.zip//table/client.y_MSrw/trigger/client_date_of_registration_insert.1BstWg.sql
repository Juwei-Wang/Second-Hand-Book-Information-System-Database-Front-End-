create definer = `skip-grants user`@`skip-grants host` trigger client_date_of_registration_insert
    before INSERT
    on client
    for each row
begin
    set new.date_of_registration = curdate();
end;

