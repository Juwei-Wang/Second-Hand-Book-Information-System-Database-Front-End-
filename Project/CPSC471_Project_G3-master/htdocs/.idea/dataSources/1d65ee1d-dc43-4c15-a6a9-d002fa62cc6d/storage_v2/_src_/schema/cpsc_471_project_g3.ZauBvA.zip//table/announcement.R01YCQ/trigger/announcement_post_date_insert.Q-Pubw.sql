create definer = `skip-grants user`@`skip-grants host` trigger announcement_post_date_insert
    before INSERT
    on announcement
    for each row
begin
    set new.post_date = curdate();
end;

