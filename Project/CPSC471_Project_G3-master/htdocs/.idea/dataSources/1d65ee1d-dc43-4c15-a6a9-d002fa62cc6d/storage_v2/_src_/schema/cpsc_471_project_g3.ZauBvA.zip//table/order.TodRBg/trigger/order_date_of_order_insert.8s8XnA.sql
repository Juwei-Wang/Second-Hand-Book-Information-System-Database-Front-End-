create definer = `skip-grants user`@`skip-grants host` trigger order_date_of_order_insert
    before INSERT
    on `order`
    for each row
begin
    set new.date_of_order = curdate();
end;

