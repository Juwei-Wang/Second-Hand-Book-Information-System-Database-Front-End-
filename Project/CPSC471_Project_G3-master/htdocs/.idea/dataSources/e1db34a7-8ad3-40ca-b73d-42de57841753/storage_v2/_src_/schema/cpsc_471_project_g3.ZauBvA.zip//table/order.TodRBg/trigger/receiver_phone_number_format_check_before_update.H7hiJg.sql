create definer = `skip-grants user`@`skip-grants host` trigger receiver_phone_number_format_check_before_update
    before UPDATE
    on `order`
    for each row
begin
    if (new.phone_number_of_receiver regexp '^1\-[0-9]{3}\-[0-9]{3}\-[0-9]{3}$') = 0 then /* 1-123-123-123 */
        signal sqlstate '12345'
            set message_text = 'invalid phone format!';
    end if;
end;

