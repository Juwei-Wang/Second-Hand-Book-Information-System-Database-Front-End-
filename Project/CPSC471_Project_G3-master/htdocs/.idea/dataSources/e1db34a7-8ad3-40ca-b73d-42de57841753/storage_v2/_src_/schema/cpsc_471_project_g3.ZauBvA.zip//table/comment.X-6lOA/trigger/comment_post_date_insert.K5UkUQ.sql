create definer = `skip-grants user`@`skip-grants host` trigger comment_post_date_insert
    before INSERT
    on comment
    for each row
begin
    set new.post_date = curdate();
end;

