create definer = `skip-grants user`@`skip-grants host` trigger order_middle_init_update
    before UPDATE
    on `order`
    for each row
begin
    if (new.middle_initial_of_receiver is not null) and
       (new.middle_initial_of_receiver regexp binary '^[a-z]$') != 0 then
        signal sqlstate '12345'
            set message_text = 'invalid middle initial!';
    end if;
end;

