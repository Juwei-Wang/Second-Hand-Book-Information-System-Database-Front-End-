create definer = `skip-grants user`@`skip-grants host` trigger administrator_phone_number_format_check_before_insert
    before INSERT
    on administrator
    for each row
begin
    if (new.phone_number regexp '^1\-[0-9]{3}\-[0-9]{3}\-[0-9]{3}$') = 0 then /* 1-123-123-123 */
        signal sqlstate '12345'
            set message_text = 'invalid phone format!';
    end if;
end;

