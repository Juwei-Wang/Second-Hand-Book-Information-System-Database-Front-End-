create definer = `skip-grants user`@`skip-grants host` trigger idea_list_keyword_initialize
    before INSERT
    on idea_list
    for each row
begin
    set new.keyword = json_array();
end;

