create definer = `skip-grants user`@`skip-grants host` trigger ucalgary_member_uppercase_name_insert
    before INSERT
    on ucalgary_member
    for each row
begin
    if (new.first_name regexp binary '^[a-z]+$') != 0 then
        signal sqlstate '12345'
            set message_text = 'invalid first name!';
    elseif (new.last_name regexp binary '^[a-z]+$') != 0 then
        signal sqlstate '12345'
            set message_text = 'invalid last name!';
    end if;
end;

