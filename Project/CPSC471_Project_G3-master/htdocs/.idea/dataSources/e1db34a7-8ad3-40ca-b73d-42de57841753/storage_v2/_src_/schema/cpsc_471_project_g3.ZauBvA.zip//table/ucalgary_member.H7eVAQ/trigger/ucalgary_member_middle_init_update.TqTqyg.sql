create definer = `skip-grants user`@`skip-grants host` trigger ucalgary_member_middle_init_update
    before UPDATE
    on ucalgary_member
    for each row
begin
    if (new.middle_initial is not null) and (new.middle_initial regexp binary '^[a-z]$') != 0 then
        signal sqlstate '12345'
            set message_text = 'invalid middle initial!';
    end if;
end;

