<table cellSpacing="0" cellPadding="0" width="780" align="center" border="0">
    <tr>
          <td width="100%" bgColor="#59be48" height="8"></td>
	</tr>
    <tr> 
      <td height="50" align="center">		
        Copyright &copy; 2008&nbsp;<?=$web_name?> All Rights 
        Reserved Ghj1983@Yahoo.Com.Cn</td>
    </tr>
</table>
