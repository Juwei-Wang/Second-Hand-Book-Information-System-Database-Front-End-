
<?
include "db.php";

########基本设置###########
$web_logo = "images/logo.jpg";	          //网站的LOGO
$web_name = "校园二手信息网";	          //网站名称
$web_http = "http://localhost/2shou2007/index.php";		      //网址
$web_bbs = "校园二手信息网开通啦!!!";            //网站公告
$web_keywords = "二手信息,二手网,卖东西,买东西,交易"; 	  //搜索关键字
$web_description ="随着Internet的普及，网络电子商务不断发展完善，B2B、B2C、C2C等各种交易模式不断产生。借助于低交易成本的Internet，二手商品市场也日趋活跃。买卖双方迫切地需要一个低成本、快速迅捷的信息发布平台。";     //站点描述

?>