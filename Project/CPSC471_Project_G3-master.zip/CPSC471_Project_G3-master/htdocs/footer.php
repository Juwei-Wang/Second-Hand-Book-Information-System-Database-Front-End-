<body>
<footer class="section">
    <div class="center grey-text">UCalgary Online Secondhand Trading System - CPSC 471 Project Group 3</div>
</footer>
</body>